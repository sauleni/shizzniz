import React from 'react'

export default function Authentication() {
    return(
        <div>
            <p>Router index.js</p>
        </div>
    )
}